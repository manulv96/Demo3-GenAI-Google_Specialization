"""OpenAPI spec agent."""
